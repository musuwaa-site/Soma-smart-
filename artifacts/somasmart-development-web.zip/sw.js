const VERSION = "c5a43c351d3a7d15",
  ASSETS = [{"url":"/assets/index-Cnav0vB3.js","sha256":"1b295ff7aabd908b417d91280c93e6306f924eda5ca09ed59aaf96966f1ca4b5"},{"url":"/assets/index-DiBvIr2j.css","sha256":"f48de28d6f754fb0ef5c6685b00c8d9a8ee00132068c605eef2aac445ffba478"},{"url":"/books/biology-f1-textbook.epub","sha256":"e942bc1e15c1873ad21a6d1aceca718c53542f6a46a8778be534d9ce359d1014"},{"url":"/books/biology-f1-workbook.epub","sha256":"3065edaff28a746437537b49cc6fd9163c97809e227ad24c71be97deb84c6beb"},{"url":"/books/biology-f2-textbook.epub","sha256":"bed7dc8dbbe6647752331664d65878a12752719ec5209125e627a0196941efa0"},{"url":"/books/biology-f2-workbook.epub","sha256":"2b37299ad9d69c7d4543d7e6248d1f544bcd05c5139801ff4ef516a32c209341"},{"url":"/books/business-f1-textbook.epub","sha256":"477376069b2272be10dea8a3688bfb80eeb8f29bc27abbe084b512e61a0d72a9"},{"url":"/books/business-f1-workbook.epub","sha256":"e7392580583b04030fa0b18f631549de1151e9cb0814d2377b914371ea0446e8"},{"url":"/books/business-f2-textbook.epub","sha256":"502175b9c520dd75442b2422c641e9c547f4c1b6fa9a89057a64955df61b2407"},{"url":"/books/business-f2-workbook.epub","sha256":"a51ac3bdadae1c311bff9c32632bb68ebd66fbe148c73acf6e784f74117c7ecd"},{"url":"/books/catalogue.json","sha256":"541ffc315f7366a9a1b8b56e08d918c1c20940d628898baf13ac817000744536"},{"url":"/books/chemistry-f1-textbook.epub","sha256":"3bf7a8ec8d792622c6b09d0d20c6bfbce458e96f6071779b59cfb430c26537a0"},{"url":"/books/chemistry-f1-workbook.epub","sha256":"9f191b68df1821a945a9a7e7bc356f767e3a3f7b109da7580a90c2f0e5d3ef13"},{"url":"/books/chemistry-f2-textbook.epub","sha256":"319319d799e3ba86189478eb92bda435f34986ea24debb9d75885d250bf5a1ea"},{"url":"/books/chemistry-f2-workbook.epub","sha256":"bbfaec7a7d708a03d437185f6f1ee9640a3ea8e66b55db471653547913c36d88"},{"url":"/books/english-f1-textbook.epub","sha256":"8b0191c2cae45bc349fd8dea5ccfbec8ea9413a0e675f8a127ecc475be5d647b"},{"url":"/books/english-f1-workbook.epub","sha256":"d6230e127891fe17da10fd9fc7586bec1f78fd7cd51efb834779bae0073cd318"},{"url":"/books/english-f2-textbook.epub","sha256":"d7451305bf93f6020473f673110b7e29d3902fe7e0e154de278d38986dd17245"},{"url":"/books/english-f2-workbook.epub","sha256":"e5310c3f8b1acff86b60f58df505fb08f1487d77462d5588895b84e1e9bd67ee"},{"url":"/books/geography-f1-textbook.epub","sha256":"e36b80ecd7f608aec0b225d0e9a8a32e3df98a9c170433ed4460d5a7b4b73011"},{"url":"/books/geography-f1-workbook.epub","sha256":"7e484c826cd6d2233712aafed79bba51477cb30620f580d5c97e62bcd7cd5315"},{"url":"/books/geography-f2-textbook.epub","sha256":"13d8752effaf969f2d36ff91895b7d4fbbef82fb86510a90a765e65d643b842c"},{"url":"/books/geography-f2-workbook.epub","sha256":"f6db1f08ef67ebd361730e7daceab332147f916d12e64a3b87aa67d60f3cec26"},{"url":"/books/historia-f1-textbook.epub","sha256":"487dfb493a55135f23f92926869b6d759027e5ff3604736289186647fd7d1a0c"},{"url":"/books/historia-f1-workbook.epub","sha256":"052e0d95c43dc1ac9b81e8fb455a62f40922237b7f1ced727cf956f3142a4edc"},{"url":"/books/historia-f2-textbook.epub","sha256":"1b5eeaa0eb1d3fe64bae0cca7e7e99c0bf646f09e5b51f0d8ade94fb3743a7b8"},{"url":"/books/historia-f2-workbook.epub","sha256":"e0780edb71bef2698b10ed27925c988928eedd85e75c0af643a55f863efb6d82"},{"url":"/books/kiswahili-f1-textbook.epub","sha256":"f02c2096c7ac3f3aa8340aa0c5669fb4207fe28c25767a71dc2284dd7106cb3a"},{"url":"/books/kiswahili-f1-workbook.epub","sha256":"ec3416e5447c04cf99cbef3f9954e18c01f38ca540338a240be2b3bc09fb7a5b"},{"url":"/books/kiswahili-f2-textbook.epub","sha256":"099dd7a04094d9ec3ad8f833e8a4d4ebe8cd0dc6e651d7fd84c73f0fe9437569"},{"url":"/books/kiswahili-f2-workbook.epub","sha256":"2127d5cbc4e1c36d5a4e6d540ce3b5a20c980417e2fcd7bce343e09a3b8aed00"},{"url":"/books/mathematics-f1-textbook.epub","sha256":"80908849ae13a6b01af59f2f5281008b829a4d9de1b78aa74dc10c5757dcd36d"},{"url":"/books/mathematics-f1-workbook.epub","sha256":"0dff37cc9b00e855908c634b05543b0441889e794c0e45515e9c1f947d246be2"},{"url":"/books/mathematics-f2-textbook.epub","sha256":"7642bd340bb6e838c8efe2e8d42bec38ac7ea076335106931e5807433c56f2b3"},{"url":"/books/mathematics-f2-workbook.epub","sha256":"92cc7e1f2043b535476c0242aa2076af8e8b5e5ba7f022b61f50a91568623e9b"},{"url":"/books/physics-f1-textbook.epub","sha256":"410231694f6d6edabaa31c6d3b35ef6c810dfa82b8a3abec1bfd1b19063ef77d"},{"url":"/books/physics-f1-workbook.epub","sha256":"868e9f16e7e2c171174aebc98c77cfb7dbb04aa2888f1e34ecb2644a92251e75"},{"url":"/books/physics-f2-textbook.epub","sha256":"923442f0062c1ac6b7eeea8353b8bca5c2ac0d2e7372c0ff7acae2c8edc8e87a"},{"url":"/books/physics-f2-workbook.epub","sha256":"524a39c62569c77498853b320114c7c5849d857cc095ff5456a858a976ef2e85"},{"url":"/diagrams/cell.svg","sha256":"4d731bf542601c27db6438f1d589355c62db33b2c35f3116656d13b3e542c25f"},{"url":"/diagrams/earth-layers.svg","sha256":"e12cfd33a4221557d8922aa04444392002cf97ba225fd4fe835778e8a9cc8dad"},{"url":"/diagrams/particles.svg","sha256":"542a57d75a09910c84bfdb0a673a136c70a069a6ef7a8b10cbe05f6d4637ed72"},{"url":"/diagrams/photosynthesis.svg","sha256":"b2aa5b2029b024c67fe95e7cce844cf7a19febfbd37f3be221e2286c4f41b00a"},{"url":"/diagrams/reflection.svg","sha256":"87e649fcd4ed83f88577a3478c977b45ce066f3378ceb0433160d07f5f51e80b"},{"url":"/diagrams/sodium.svg","sha256":"a7436dbb6c0af54ce3938f4d69d560ee797f23bac1ce3f58aa243d580ac289d2"},{"url":"/exams/catalogue.json","sha256":"d70624d5e22efc8e2a9a919b7de5c649b6342b520a2034dc34a2886df0893277"},{"url":"/exams/original-revision-f1-biology-01-answers.pdf","sha256":"c66ef5d05103c9b1ddf5c50056be78c309d3882a0487235d2d8d536f25d0fd4f"},{"url":"/exams/original-revision-f1-biology-01.pdf","sha256":"641ba14c4c9e21d203bc06f103b4e5a0a9558fdf82a85201f6b48d72753d8e1c"},{"url":"/exams/original-revision-f1-business-01-answers.pdf","sha256":"0a15e1927a19bbe086c59c9df3490447a9edb37e108138f5474a8b1417ac59db"},{"url":"/exams/original-revision-f1-business-01.pdf","sha256":"50d979fd25078de24f36f543b6cdf8643171e80ba74ec57eaf6c6ab04c23d7f6"},{"url":"/exams/original-revision-f1-chemistry-01-answers.pdf","sha256":"ce4f3a9b0cff415f4881f55032f5179847ac89541725613537ecc085dadd938a"},{"url":"/exams/original-revision-f1-chemistry-01.pdf","sha256":"05babf96e4cce6963f1b6b375677beb55a5ab559cdb34e233a3e4d0d8a58d8bd"},{"url":"/exams/original-revision-f1-english-01-answers.pdf","sha256":"ba3336909c92c3bf1f712991553cb55c067ec5c19067a66135f25651ced4f84b"},{"url":"/exams/original-revision-f1-english-01.pdf","sha256":"ef2bc8d72f984c75c4c0a1a2d8dfea5491d121221d58f20640950d4269887501"},{"url":"/exams/original-revision-f1-geography-01-answers.pdf","sha256":"b186f4fa5fbe0aed0e6b2b6d8eef5d2299006661e4951f4b4908afd82e8c9327"},{"url":"/exams/original-revision-f1-geography-01.pdf","sha256":"1436f4c7e9f5164ac5859552258b4d551d44b181cec00f6fc7330d3af35b1fa2"},{"url":"/exams/original-revision-f1-historia-01-answers.pdf","sha256":"8551612365be18a24bc3191b27d6136b808f3b0861329d7181a9a9c4ebce04f9"},{"url":"/exams/original-revision-f1-historia-01.pdf","sha256":"54f24408bd032d243d176291c528fe5c6a9161d39ce9809ad5bc89425c23652e"},{"url":"/exams/original-revision-f1-kiswahili-01-answers.pdf","sha256":"384f7fdd853a628a75aca450daf3ab61bed69c3545d22283a5489da759b6b827"},{"url":"/exams/original-revision-f1-kiswahili-01.pdf","sha256":"a06079b0f33a43c6cd1dd7061f0167dd8d7f324b593c9aad5d19dcd0075d1726"},{"url":"/exams/original-revision-f1-mathematics-01-answers.pdf","sha256":"18775e7d1b1c8b2099850064de0e03bd0a1ed0362554adc7bf8a5a562bf1c148"},{"url":"/exams/original-revision-f1-mathematics-01.pdf","sha256":"06cc34d4445e6bf3ba5365c2119d98ef9060bb9f1c18b5764c9107183e3b3025"},{"url":"/exams/original-revision-f1-physics-01-answers.pdf","sha256":"516c09c13dc9d881582616dd5a13b79d8839de6d5f1d998b68f767efec580ac6"},{"url":"/exams/original-revision-f1-physics-01.pdf","sha256":"18852d7dbf97d43f3abe533f770128f7b531ceac1d46d67b638b3d1e7cc30e0d"},{"url":"/exams/original-revision-f2-biology-01-answers.pdf","sha256":"a9ae36de1cfdd0caf4691af1a15f75c879b31eced5300e2ce8ea92932dd9982c"},{"url":"/exams/original-revision-f2-biology-01.pdf","sha256":"faeaa28fe267be8b63daf2f99223b04db366e07e6a217b39bc430abb420b4173"},{"url":"/exams/original-revision-f2-business-01-answers.pdf","sha256":"c25333d13885de36ec1dd175747864a8f3bdbe25d2b17e5095fda91e78591d62"},{"url":"/exams/original-revision-f2-business-01.pdf","sha256":"3b0a30f94f80d02fb9d529c41cb89f5d116097f68700ab7d72b79f6f26bff48c"},{"url":"/exams/original-revision-f2-chemistry-01-answers.pdf","sha256":"82f2c73de43e161e5fa49e3623d839c0784b0be0f721ce8e061fc0ad399ed1e0"},{"url":"/exams/original-revision-f2-chemistry-01.pdf","sha256":"7cf34c91bdfb210ae84893548ba671ac87e3169eb8741618c7ebe17deaf27f23"},{"url":"/exams/original-revision-f2-english-01-answers.pdf","sha256":"ede26cba20b0713a311bf1bbbeda76ce721cc97b4f53893dbfd2ebba253d23ab"},{"url":"/exams/original-revision-f2-english-01.pdf","sha256":"13bce201d68caa125bcbc9624cba0b16da943a46dbc4fbbace217d93f7d0414e"},{"url":"/exams/original-revision-f2-geography-01-answers.pdf","sha256":"96dd9f0fbcd92a0c564e0bf72a5fcd46d6fecd7fc1dc70080e80c3cdb177966f"},{"url":"/exams/original-revision-f2-geography-01.pdf","sha256":"152b3c776e034f0c3a964829686922e1a83efc5baae5a957ee6ff913b6bf8459"},{"url":"/exams/original-revision-f2-historia-01-answers.pdf","sha256":"49da8bef018104a332795e9672c9282bff448f8c91cacd5e975dfc1adaf02342"},{"url":"/exams/original-revision-f2-historia-01.pdf","sha256":"c11cbe262da48aca1f8063804f6b4d247f0a812ce6d2d6f5d0953f6aace5033b"},{"url":"/exams/original-revision-f2-kiswahili-01-answers.pdf","sha256":"2e5655eae59702fc1ef93dc98e8fcb7752aba0eee6590039c6353709ec1482e2"},{"url":"/exams/original-revision-f2-kiswahili-01.pdf","sha256":"b91e238f88a71b5f30c88fa791c743b1f0006510c3022fd1bb3a5e8e32dafaa3"},{"url":"/exams/original-revision-f2-mathematics-01-answers.pdf","sha256":"5c11d0bfaf20b2954997c30c2605f281e22638bab4d816ac12c983ffaedc4dd6"},{"url":"/exams/original-revision-f2-mathematics-01.pdf","sha256":"0cbe2ab1e9ed1d1b8dc992a62d9c5a440cf22bf9a3de648e4219016ffc0ff454"},{"url":"/exams/original-revision-f2-physics-01-answers.pdf","sha256":"3c8bd93bc7bec72363ef6580f24d44b17a903ac827cd15c366532435b989a237"},{"url":"/exams/original-revision-f2-physics-01.pdf","sha256":"f536ba5b0082655a0bc78b2e7fee11915ab7d204d32d494f76c53f136d2fb846"},{"url":"/icon-192.png","sha256":"b7a0a6140d6d42e761b6a9a04d9d055ff56cfae253adc8a87300ea7b252c2733"},{"url":"/icon-512.png","sha256":"1eb9acbf92a349f2255c036a564351b23f755db842de4fadf4a084574839b140"},{"url":"/icon.svg","sha256":"13d57be9ebaea428945951ec48701809fb54413654053c4ec3765d3633402129"},{"url":"/index.html","sha256":"fdd7b27afd7f26f1b05bbea53536d98a3deedf2b7bceafadefd6e74785612555"},{"url":"/library.json","sha256":"877788f43f16c14f09a1792aaa979ad986f882bb41840d564922995a1482be96"},{"url":"/manifest.webmanifest","sha256":"cda8a3ccfaed82e3ea7b64054c14d5139f077fca319976fbf04863b494718247"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/original.pdf","sha256":"200032d2d5376daf1882823a8847b9d4f17ac21fe1309f63062cc8ffbda099fb"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-1.png","sha256":"cb00f0eb0945c143f5ba19cf00faee564c705078544059a727356c543a418ec5"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-10.png","sha256":"d52ab4f2e128dfec9d54701383c712df6ce25bc18e0bb67806c131933bf1c5f9"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-11.png","sha256":"e75bc9ca46c2728299e77c812646eb2a3841e17da36abe69dc2525f3eb09617a"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-2.png","sha256":"fb75a99f9c537de87ad4bbb6ea076f593a4bbf15c9a408eed6085f763f868413"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-4.png","sha256":"bf4f3dd9c4c4a88052fd2d17db936fd778e506188fe5c9c7d31ab810655bea1f"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-5.png","sha256":"76939cc7d54dda051f49c1bf60a004206fbb60c0360e3d1bc2e707a69d770f03"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-6.png","sha256":"08091feedced935640f3fb5137676ea55e5051e467444b13ff5c4f080cdbabc9"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-7.png","sha256":"29407e03f8d92d9085d4968afb57397964fdbcbf07023c1a6c68ebd5f8a18b4a"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-8.png","sha256":"a39a7784f2b080693146c6e70dcd576c91bf627d6cf060997c2ef7536c54d417"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/page-9.png","sha256":"af87eb18f2c89bc3c271022a737434727dbafdc459ec53144986960a80c82e7e"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/q4-angles.png","sha256":"ef36cd8e37fa9352eba555d31f7f0bb843e8831d9e1389733480794bfb0be165"},{"url":"/past-papers/necta-ftna-2025-mathematics-200032d2d5376daf/q9-triangle.png","sha256":"b03515010241d38bb4a5ee6d275d5239ec95aa734e917fc1b523f32198211c1b"}],
  CACHE = "somasmart-" + VERSION;
async function broadcast(message) {
  for (const c of await self.clients.matchAll({ includeUncontrolled: true }))
    c.postMessage(message);
}
async function digest(response) {
  return [
    ...new Uint8Array(
      await crypto.subtle.digest("SHA-256", await response.arrayBuffer()),
    ),
  ]
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
}
async function valid(cache) {
  for (const asset of ASSETS) {
    const response = await cache.match(asset.url);
    if (!response || (await digest(response)) !== asset.sha256) return false;
  }
  return true;
}
self.addEventListener("install", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      let done = 0;
      try {
        for (const asset of ASSETS) {
          const existing = await cache.match(asset.url);
          if (!existing || (await digest(existing)) !== asset.sha256) {
            const response = await fetch(asset.url, { cache: "no-store" });
            if (
              !response.ok ||
              (await digest(response.clone())) !== asset.sha256
            )
              throw Error("Missing or corrupted asset: " + asset.url);
            await cache.put(asset.url, response);
          }
          await broadcast({
            type: "PROGRESS",
            done: ++done,
            total: ASSETS.length,
          });
        }
        if (!(await valid(cache)))
          throw Error("Offline content validation failed");
        await self.skipWaiting();
      } catch (e) {
        await broadcast({
          type: "ERROR",
          message:
            e.name === "QuotaExceededError"
              ? "Not enough storage. Free space and retry."
              : e.message,
        });
        throw e;
      }
    })(),
  ),
);
self.addEventListener("activate", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      if (!(await valid(cache)))
        throw Error("Refusing incomplete offline release");
      await self.clients.claim(); // Older complete versions remain available for rollback; never clear student IndexedDB.
      await broadcast({ type: "READY", version: VERSION });
    })(),
  ),
);
self.addEventListener("message", (event) => {
  if (event.data.type === "STATUS")
    event.waitUntil(
      (async () => {
        const ready = await valid(await caches.open(CACHE));
        event.ports[0]?.postMessage({ ready, version: VERSION });
      })(),
    );
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin)
    return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE);
      if (event.request.mode === "navigate")
        return (await cache.match("/index.html")) || fetch(event.request);
      const asset = ASSETS.find((a) => a.url === url.pathname);
      if (asset) {
        const response = await cache.match(asset.url);
        if (response && (await digest(response.clone())) === asset.sha256)
          return response;
        const fresh = await fetch(event.request);
        if (!fresh.ok || (await digest(fresh.clone())) !== asset.sha256)
          throw Error("Asset integrity failure");
        await cache.put(asset.url, fresh.clone());
        return fresh;
      }
      return fetch(event.request);
    })(),
  );
});
