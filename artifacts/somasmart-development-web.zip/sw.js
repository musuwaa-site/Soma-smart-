const VERSION = "4e49a1dc845cca84",
  ASSETS = [{"url":"/assets/index-BNDdsK8_.js","sha256":"a7caae0367023c0f8e7f1555a7ca29dea3fb27873ebaf4e5a34fcaedf2f0f1aa"},{"url":"/assets/index-DiBvIr2j.css","sha256":"f48de28d6f754fb0ef5c6685b00c8d9a8ee00132068c605eef2aac445ffba478"},{"url":"/diagrams/cell.svg","sha256":"4d731bf542601c27db6438f1d589355c62db33b2c35f3116656d13b3e542c25f"},{"url":"/diagrams/earth-layers.svg","sha256":"e12cfd33a4221557d8922aa04444392002cf97ba225fd4fe835778e8a9cc8dad"},{"url":"/diagrams/particles.svg","sha256":"542a57d75a09910c84bfdb0a673a136c70a069a6ef7a8b10cbe05f6d4637ed72"},{"url":"/diagrams/photosynthesis.svg","sha256":"b2aa5b2029b024c67fe95e7cce844cf7a19febfbd37f3be221e2286c4f41b00a"},{"url":"/diagrams/reflection.svg","sha256":"87e649fcd4ed83f88577a3478c977b45ce066f3378ceb0433160d07f5f51e80b"},{"url":"/diagrams/sodium.svg","sha256":"a7436dbb6c0af54ce3938f4d69d560ee797f23bac1ce3f58aa243d580ac289d2"},{"url":"/icon-192.png","sha256":"b7a0a6140d6d42e761b6a9a04d9d055ff56cfae253adc8a87300ea7b252c2733"},{"url":"/icon-512.png","sha256":"1eb9acbf92a349f2255c036a564351b23f755db842de4fadf4a084574839b140"},{"url":"/icon.svg","sha256":"13d57be9ebaea428945951ec48701809fb54413654053c4ec3765d3633402129"},{"url":"/index.html","sha256":"997495469ff06818603cef21074f68cccc30c6e654cdd1f67502e1040f0026f9"},{"url":"/library.json","sha256":"85185fb07661d12a0b1c936951235f23e60a81268b93f45af240717474bcc498"},{"url":"/manifest.webmanifest","sha256":"cda8a3ccfaed82e3ea7b64054c14d5139f077fca319976fbf04863b494718247"}],
  CACHE = "somasmart-" + VERSION;
async function broadcast(message) {
  for (const c of await self.clients.matchAll({ includeUncontrolled: true }))
    c.postMessage(message);
}
async function digest(response) {
  return [
    ...new Uint8Array(
      await crypto.subtle.digest("SHA-256", await response.arrayBuffer()),
    ),
  ]
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
}
async function valid(cache) {
  for (const asset of ASSETS) {
    const response = await cache.match(asset.url);
    if (!response || (await digest(response)) !== asset.sha256) return false;
  }
  return true;
}
self.addEventListener("install", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      let done = 0;
      try {
        for (const asset of ASSETS) {
          const existing = await cache.match(asset.url);
          if (!existing || (await digest(existing)) !== asset.sha256) {
            const response = await fetch(asset.url, { cache: "no-store" });
            if (
              !response.ok ||
              (await digest(response.clone())) !== asset.sha256
            )
              throw Error("Missing or corrupted asset: " + asset.url);
            await cache.put(asset.url, response);
          }
          await broadcast({
            type: "PROGRESS",
            done: ++done,
            total: ASSETS.length,
          });
        }
        if (!(await valid(cache)))
          throw Error("Offline content validation failed");
        await self.skipWaiting();
      } catch (e) {
        await broadcast({
          type: "ERROR",
          message:
            e.name === "QuotaExceededError"
              ? "Not enough storage. Free space and retry."
              : e.message,
        });
        throw e;
      }
    })(),
  ),
);
self.addEventListener("activate", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      if (!(await valid(cache)))
        throw Error("Refusing incomplete offline release");
      await self.clients.claim(); // Older complete versions remain available for rollback; never clear student IndexedDB.
      await broadcast({ type: "READY", version: VERSION });
    })(),
  ),
);
self.addEventListener("message", (event) => {
  if (event.data.type === "STATUS")
    event.waitUntil(
      (async () => {
        const ready = await valid(await caches.open(CACHE));
        event.ports[0]?.postMessage({ ready, version: VERSION });
      })(),
    );
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin)
    return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE);
      if (event.request.mode === "navigate")
        return (await cache.match("/index.html")) || fetch(event.request);
      const asset = ASSETS.find((a) => a.url === url.pathname);
      if (asset) {
        const response = await cache.match(asset.url);
        if (response && (await digest(response.clone())) === asset.sha256)
          return response;
        const fresh = await fetch(event.request);
        if (!fresh.ok || (await digest(fresh.clone())) !== asset.sha256)
          throw Error("Asset integrity failure");
        await cache.put(asset.url, fresh.clone());
        return fresh;
      }
      return fetch(event.request);
    })(),
  );
});
