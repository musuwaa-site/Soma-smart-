const VERSION = "53d782ae14f1b766",
  ASSETS = [{"url":"/assets/index-CVRCc8To.js","sha256":"daa2dd11cfd3d9d4e2d25397b70206fb162cca22cd46158f67eb58e30cb6717f"},{"url":"/assets/index-DiBvIr2j.css","sha256":"f48de28d6f754fb0ef5c6685b00c8d9a8ee00132068c605eef2aac445ffba478"},{"url":"/books/biology-f1-textbook.epub","sha256":"ab4653e29250daac001fef92d2fe6a7e198bf214df9af549b25abab8fa14f383"},{"url":"/books/biology-f1-workbook.epub","sha256":"ff4913d84382280410d013c66f3e42e86b2616eaa0382e0e05b3b936b515ace7"},{"url":"/books/biology-f2-textbook.epub","sha256":"25f593559144b6552b0c07bfe108fffd39a890ec2619c5c448fd62503ab581e9"},{"url":"/books/biology-f2-workbook.epub","sha256":"e133e95c4d463562a4954b6c14505820c7f3c066dd8a6e28bcbdf41b62b96c31"},{"url":"/books/business-f1-textbook.epub","sha256":"ca379afee79491656aa6a59887efcf3938a73e20b972c136d6f34ea1794dc18f"},{"url":"/books/business-f1-workbook.epub","sha256":"ee0c0ecf59bad6aa9d50b1a9f28b9051f3925970e8c820ca36612e2f0ae840d2"},{"url":"/books/business-f2-textbook.epub","sha256":"355825995656f1f067f12d0d0d61a43cdb3fb4f73ffaa7a8e5d11ec96943c2bb"},{"url":"/books/business-f2-workbook.epub","sha256":"3639c0ccde91f8bb56cca031b23a73aee9117b475b9feee0c6a1963c95e7621d"},{"url":"/books/catalogue.json","sha256":"7c4df610220b56644155f40212f04ec06c7def0e67ce08e0de7f7d15b3381926"},{"url":"/books/chemistry-f1-textbook.epub","sha256":"0941ee56f20ccd8a67b09b343028bb05824df719d85361ba4570d63d58881f51"},{"url":"/books/chemistry-f1-workbook.epub","sha256":"9cc4bc0d0694473141039bd9d15c321673e13e5c5a65503449992a89bdb5e621"},{"url":"/books/chemistry-f2-textbook.epub","sha256":"aae69e2e5b14f793a3a4c0bffd4b8348a92d7780ab9b06088b1b44eb8d09b561"},{"url":"/books/chemistry-f2-workbook.epub","sha256":"fd4da492894bf0bb56261c855f719e80ca057539e1494ace89f201db98bff689"},{"url":"/books/english-f1-textbook.epub","sha256":"2950b6a5582dcf20f3f158072d005205e24326afff18b553a74d46bd8cce7ad2"},{"url":"/books/english-f1-workbook.epub","sha256":"1082580e6c96dedde3b08268d8bfc1dff807c24e978e20308d02da6ec22d5663"},{"url":"/books/english-f2-textbook.epub","sha256":"1e65190ca5f27088fb75011f5e03e3772700580572e0578e89e162db9c493cfb"},{"url":"/books/english-f2-workbook.epub","sha256":"4c9198f69582ca5d36954e9d3ef8c482e3244aa49c7ac013c1e5a84b8f428f2a"},{"url":"/books/geography-f1-textbook.epub","sha256":"ea04c9de1b562efc5a999a2a57c150a23af137ef00aef4ae3d0182b805f49e50"},{"url":"/books/geography-f1-workbook.epub","sha256":"51eac9d8ea1ef6b41660954b73cb5440ed99d98c953d58e0dfed9d127cd10403"},{"url":"/books/geography-f2-textbook.epub","sha256":"8d9bd32e425b0250da8a287facdd4cdec922339213f57e718f0a7bdb40317916"},{"url":"/books/geography-f2-workbook.epub","sha256":"3da83c51b68c6229824107828b5ea3d0770b2fc7f23100675bf1078ef0f1e0dd"},{"url":"/books/historia-f1-textbook.epub","sha256":"5edee64d797f96ad49ed6c5d3539d9fbd4d5795acac6961ae8ac1ce8064ee2a3"},{"url":"/books/historia-f1-workbook.epub","sha256":"8c8f190b526b87871fbe85c29d09b9ed6e3a29e8b03c9412fa234f984b4d369a"},{"url":"/books/historia-f2-textbook.epub","sha256":"374cc3e83b3b5e2113ab723acbc98d752e049de50913470db761e77ccd0bbcf6"},{"url":"/books/historia-f2-workbook.epub","sha256":"f1e7fba83f3f5ee7fcb932d2a2a43067520cdc411641a862b4bd2eac476b76fa"},{"url":"/books/kiswahili-f1-textbook.epub","sha256":"897047be7d7c602ad8cb763ce90ba0e0065122c3b895fbbd647a2ed6d90b3e51"},{"url":"/books/kiswahili-f1-workbook.epub","sha256":"2bca32d4682ad67ef144cb2116c4ceec136c996bd65a67176b7328477b9d7b72"},{"url":"/books/kiswahili-f2-textbook.epub","sha256":"f9a5984610d8e9a46e687f6361bb09747bac2a8c1882310ce832b734f9045a1a"},{"url":"/books/kiswahili-f2-workbook.epub","sha256":"cd2ac026f03c7fd4c73ea68cea6d48caf4e490204fdda96a6fcb48e50baa9a49"},{"url":"/books/mathematics-f1-textbook.epub","sha256":"718a0159f2be86f2ebd9b80cebef1babea23271fa1f083718cb0ba5402072898"},{"url":"/books/mathematics-f1-workbook.epub","sha256":"28d335f415508c563224bd6cc5891e8ca49970ca384c0b3c36d7de1464fa7f66"},{"url":"/books/mathematics-f2-textbook.epub","sha256":"03314732d0777cfc26a3d05440ec219e93934849426d13852ad0a41126cb8afc"},{"url":"/books/mathematics-f2-workbook.epub","sha256":"2730e1b0078c9dcc81f34066cf63dfef3cfa1c070e3ee6ebf094f5f56c6abfe1"},{"url":"/books/physics-f1-textbook.epub","sha256":"5b2f2f4065650fabfbedb7b07bf69e5ea11327a1480c463d7d15c3f331a37a60"},{"url":"/books/physics-f1-workbook.epub","sha256":"9f956cfc01af57f437442d9ce39e3b3fb2bb61e636e73e0a7d3c1a26a27d4b92"},{"url":"/books/physics-f2-textbook.epub","sha256":"2488688da8d90e4481f449f3c693bd495db052b2682edbc8aac246d7b3af65f5"},{"url":"/books/physics-f2-workbook.epub","sha256":"4cf29044cb01cc922c7a7730e06229e27bfb1688abf0aa6e190ad49798c976b2"},{"url":"/diagrams/cell.svg","sha256":"4d731bf542601c27db6438f1d589355c62db33b2c35f3116656d13b3e542c25f"},{"url":"/diagrams/earth-layers.svg","sha256":"e12cfd33a4221557d8922aa04444392002cf97ba225fd4fe835778e8a9cc8dad"},{"url":"/diagrams/particles.svg","sha256":"542a57d75a09910c84bfdb0a673a136c70a069a6ef7a8b10cbe05f6d4637ed72"},{"url":"/diagrams/photosynthesis.svg","sha256":"b2aa5b2029b024c67fe95e7cce844cf7a19febfbd37f3be221e2286c4f41b00a"},{"url":"/diagrams/reflection.svg","sha256":"87e649fcd4ed83f88577a3478c977b45ce066f3378ceb0433160d07f5f51e80b"},{"url":"/diagrams/sodium.svg","sha256":"a7436dbb6c0af54ce3938f4d69d560ee797f23bac1ce3f58aa243d580ac289d2"},{"url":"/exams/catalogue.json","sha256":"d70624d5e22efc8e2a9a919b7de5c649b6342b520a2034dc34a2886df0893277"},{"url":"/exams/original-revision-f1-biology-01-answers.pdf","sha256":"c66ef5d05103c9b1ddf5c50056be78c309d3882a0487235d2d8d536f25d0fd4f"},{"url":"/exams/original-revision-f1-biology-01.pdf","sha256":"641ba14c4c9e21d203bc06f103b4e5a0a9558fdf82a85201f6b48d72753d8e1c"},{"url":"/exams/original-revision-f1-business-01-answers.pdf","sha256":"0a15e1927a19bbe086c59c9df3490447a9edb37e108138f5474a8b1417ac59db"},{"url":"/exams/original-revision-f1-business-01.pdf","sha256":"50d979fd25078de24f36f543b6cdf8643171e80ba74ec57eaf6c6ab04c23d7f6"},{"url":"/exams/original-revision-f1-chemistry-01-answers.pdf","sha256":"ce4f3a9b0cff415f4881f55032f5179847ac89541725613537ecc085dadd938a"},{"url":"/exams/original-revision-f1-chemistry-01.pdf","sha256":"05babf96e4cce6963f1b6b375677beb55a5ab559cdb34e233a3e4d0d8a58d8bd"},{"url":"/exams/original-revision-f1-english-01-answers.pdf","sha256":"ba3336909c92c3bf1f712991553cb55c067ec5c19067a66135f25651ced4f84b"},{"url":"/exams/original-revision-f1-english-01.pdf","sha256":"ef2bc8d72f984c75c4c0a1a2d8dfea5491d121221d58f20640950d4269887501"},{"url":"/exams/original-revision-f1-geography-01-answers.pdf","sha256":"b186f4fa5fbe0aed0e6b2b6d8eef5d2299006661e4951f4b4908afd82e8c9327"},{"url":"/exams/original-revision-f1-geography-01.pdf","sha256":"1436f4c7e9f5164ac5859552258b4d551d44b181cec00f6fc7330d3af35b1fa2"},{"url":"/exams/original-revision-f1-historia-01-answers.pdf","sha256":"8551612365be18a24bc3191b27d6136b808f3b0861329d7181a9a9c4ebce04f9"},{"url":"/exams/original-revision-f1-historia-01.pdf","sha256":"54f24408bd032d243d176291c528fe5c6a9161d39ce9809ad5bc89425c23652e"},{"url":"/exams/original-revision-f1-kiswahili-01-answers.pdf","sha256":"384f7fdd853a628a75aca450daf3ab61bed69c3545d22283a5489da759b6b827"},{"url":"/exams/original-revision-f1-kiswahili-01.pdf","sha256":"a06079b0f33a43c6cd1dd7061f0167dd8d7f324b593c9aad5d19dcd0075d1726"},{"url":"/exams/original-revision-f1-mathematics-01-answers.pdf","sha256":"18775e7d1b1c8b2099850064de0e03bd0a1ed0362554adc7bf8a5a562bf1c148"},{"url":"/exams/original-revision-f1-mathematics-01.pdf","sha256":"06cc34d4445e6bf3ba5365c2119d98ef9060bb9f1c18b5764c9107183e3b3025"},{"url":"/exams/original-revision-f1-physics-01-answers.pdf","sha256":"516c09c13dc9d881582616dd5a13b79d8839de6d5f1d998b68f767efec580ac6"},{"url":"/exams/original-revision-f1-physics-01.pdf","sha256":"18852d7dbf97d43f3abe533f770128f7b531ceac1d46d67b638b3d1e7cc30e0d"},{"url":"/exams/original-revision-f2-biology-01-answers.pdf","sha256":"a9ae36de1cfdd0caf4691af1a15f75c879b31eced5300e2ce8ea92932dd9982c"},{"url":"/exams/original-revision-f2-biology-01.pdf","sha256":"faeaa28fe267be8b63daf2f99223b04db366e07e6a217b39bc430abb420b4173"},{"url":"/exams/original-revision-f2-business-01-answers.pdf","sha256":"c25333d13885de36ec1dd175747864a8f3bdbe25d2b17e5095fda91e78591d62"},{"url":"/exams/original-revision-f2-business-01.pdf","sha256":"3b0a30f94f80d02fb9d529c41cb89f5d116097f68700ab7d72b79f6f26bff48c"},{"url":"/exams/original-revision-f2-chemistry-01-answers.pdf","sha256":"82f2c73de43e161e5fa49e3623d839c0784b0be0f721ce8e061fc0ad399ed1e0"},{"url":"/exams/original-revision-f2-chemistry-01.pdf","sha256":"7cf34c91bdfb210ae84893548ba671ac87e3169eb8741618c7ebe17deaf27f23"},{"url":"/exams/original-revision-f2-english-01-answers.pdf","sha256":"ede26cba20b0713a311bf1bbbeda76ce721cc97b4f53893dbfd2ebba253d23ab"},{"url":"/exams/original-revision-f2-english-01.pdf","sha256":"13bce201d68caa125bcbc9624cba0b16da943a46dbc4fbbace217d93f7d0414e"},{"url":"/exams/original-revision-f2-geography-01-answers.pdf","sha256":"96dd9f0fbcd92a0c564e0bf72a5fcd46d6fecd7fc1dc70080e80c3cdb177966f"},{"url":"/exams/original-revision-f2-geography-01.pdf","sha256":"152b3c776e034f0c3a964829686922e1a83efc5baae5a957ee6ff913b6bf8459"},{"url":"/exams/original-revision-f2-historia-01-answers.pdf","sha256":"49da8bef018104a332795e9672c9282bff448f8c91cacd5e975dfc1adaf02342"},{"url":"/exams/original-revision-f2-historia-01.pdf","sha256":"c11cbe262da48aca1f8063804f6b4d247f0a812ce6d2d6f5d0953f6aace5033b"},{"url":"/exams/original-revision-f2-kiswahili-01-answers.pdf","sha256":"2e5655eae59702fc1ef93dc98e8fcb7752aba0eee6590039c6353709ec1482e2"},{"url":"/exams/original-revision-f2-kiswahili-01.pdf","sha256":"b91e238f88a71b5f30c88fa791c743b1f0006510c3022fd1bb3a5e8e32dafaa3"},{"url":"/exams/original-revision-f2-mathematics-01-answers.pdf","sha256":"5c11d0bfaf20b2954997c30c2605f281e22638bab4d816ac12c983ffaedc4dd6"},{"url":"/exams/original-revision-f2-mathematics-01.pdf","sha256":"0cbe2ab1e9ed1d1b8dc992a62d9c5a440cf22bf9a3de648e4219016ffc0ff454"},{"url":"/exams/original-revision-f2-physics-01-answers.pdf","sha256":"3c8bd93bc7bec72363ef6580f24d44b17a903ac827cd15c366532435b989a237"},{"url":"/exams/original-revision-f2-physics-01.pdf","sha256":"f536ba5b0082655a0bc78b2e7fee11915ab7d204d32d494f76c53f136d2fb846"},{"url":"/icon-192.png","sha256":"b7a0a6140d6d42e761b6a9a04d9d055ff56cfae253adc8a87300ea7b252c2733"},{"url":"/icon-512.png","sha256":"1eb9acbf92a349f2255c036a564351b23f755db842de4fadf4a084574839b140"},{"url":"/icon.svg","sha256":"13d57be9ebaea428945951ec48701809fb54413654053c4ec3765d3633402129"},{"url":"/index.html","sha256":"7e925f3d8b87e1ba6cf088e0d65a64fad974b831fd78f400e203aea603162d12"},{"url":"/library.json","sha256":"2d5052910a396701d336e83d308de151aecefc2ffe4bd516c3f7db1ff9f0d6b3"},{"url":"/manifest.webmanifest","sha256":"cda8a3ccfaed82e3ea7b64054c14d5139f077fca319976fbf04863b494718247"}],
  CACHE = "somasmart-" + VERSION;
async function broadcast(message) {
  for (const c of await self.clients.matchAll({ includeUncontrolled: true }))
    c.postMessage(message);
}
async function digest(response) {
  return [
    ...new Uint8Array(
      await crypto.subtle.digest("SHA-256", await response.arrayBuffer()),
    ),
  ]
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
}
async function valid(cache) {
  for (const asset of ASSETS) {
    const response = await cache.match(asset.url);
    if (!response || (await digest(response)) !== asset.sha256) return false;
  }
  return true;
}
self.addEventListener("install", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      let done = 0;
      try {
        for (const asset of ASSETS) {
          const existing = await cache.match(asset.url);
          if (!existing || (await digest(existing)) !== asset.sha256) {
            const response = await fetch(asset.url, { cache: "no-store" });
            if (
              !response.ok ||
              (await digest(response.clone())) !== asset.sha256
            )
              throw Error("Missing or corrupted asset: " + asset.url);
            await cache.put(asset.url, response);
          }
          await broadcast({
            type: "PROGRESS",
            done: ++done,
            total: ASSETS.length,
          });
        }
        if (!(await valid(cache)))
          throw Error("Offline content validation failed");
        await self.skipWaiting();
      } catch (e) {
        await broadcast({
          type: "ERROR",
          message:
            e.name === "QuotaExceededError"
              ? "Not enough storage. Free space and retry."
              : e.message,
        });
        throw e;
      }
    })(),
  ),
);
self.addEventListener("activate", (event) =>
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      if (!(await valid(cache)))
        throw Error("Refusing incomplete offline release");
      await self.clients.claim(); // Older complete versions remain available for rollback; never clear student IndexedDB.
      await broadcast({ type: "READY", version: VERSION });
    })(),
  ),
);
self.addEventListener("message", (event) => {
  if (event.data.type === "STATUS")
    event.waitUntil(
      (async () => {
        const ready = await valid(await caches.open(CACHE));
        event.ports[0]?.postMessage({ ready, version: VERSION });
      })(),
    );
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin)
    return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE);
      if (event.request.mode === "navigate")
        return (await cache.match("/index.html")) || fetch(event.request);
      const asset = ASSETS.find((a) => a.url === url.pathname);
      if (asset) {
        const response = await cache.match(asset.url);
        if (response && (await digest(response.clone())) === asset.sha256)
          return response;
        const fresh = await fetch(event.request);
        if (!fresh.ok || (await digest(fresh.clone())) !== asset.sha256)
          throw Error("Asset integrity failure");
        await cache.put(asset.url, fresh.clone());
        return fresh;
      }
      return fetch(event.request);
    })(),
  );
});
